// ===== COMMON: login, data, helpers and page renderer (loaded on every page) =====
const LOGIN=document.body.dataset.page=='login';
try{localStorage.removeItem('cl_user')}catch(e){}
if(LOGIN){try{sessionStorage.removeItem('cl_user')}catch(e){}}
const CRED={user:['user@example.com','user123','User','home.html'],admin:['yuvraj.salaria@careerlaunch.com','Yuvraj@123','Yuvraj Singh Salaria','admin-dashboard.html']};
let cu=null;try{cu=JSON.parse(sessionStorage.getItem('cl_user'))}catch(e){}
if(cu&&cu.role=='admin'&&cu.email=='admin@careerlaunch.com'){cu={role:'admin',name:CRED.admin[2],email:CRED.admin[0]};try{sessionStorage.setItem('cl_user',JSON.stringify(cu))}catch(e){}}
if(!LOGIN){if(!cu)location.replace('index.html');else if(document.body.dataset.panel=='a'&&cu.role!='admin')location.replace('home.html')}
const LO=()=>{try{sessionStorage.removeItem('cl_user')}catch(e){}location.href='index.html'};
document.addEventListener('click',e=>{if(e.target.closest('#lo,[data-lo]')){e.preventDefault();LO()}});
// App data, saved settings and shared state
const UN=[['home','🏠','Home'],['roadmaps','🧭','Roadmaps'],['resources','📄','Resources'],['interview','🎤','Interview Prep'],['dashboard','📊','Dashboard'],['editprofile','✏️','Edit Profile']];
const AN=[['dashboard','📊','Dashboard'],['roadmaps','🧭','Roadmaps'],['resources','📄','Resources'],['interviews','🎤','Interviews'],['addstudent','🎓','Add Student'],['profile','👤','Profile'],['settings','⚙️','Settings']];
const TT=['HR Questions','Technical','Aptitude','GD Topics','Tips'];
const DEF=['Learn the fundamentals','Practise with small projects','Build a portfolio project','Get feedback and improve','Apply for internships and jobs'];
const CATS=['Development','Data','Design','Security','Cloud','Business'];
const RM=[
['Web Development','Development','🌐','HTML, CSS, JavaScript, frameworks and deployment.',['Learn HTML and CSS basics','Master JavaScript fundamentals','Build responsive layouts','Learn Git and GitHub','Pick a framework (React or Vue)','Deploy 3 portfolio projects']],
['Java Developer','Development','☕','Core Java, Spring and backend fundamentals.',['Core Java and OOP','Collections and Streams','JDBC and SQL','Spring Boot REST APIs','Testing with JUnit','Build a full-stack project']],
['Data Science','Data','📈','Python, statistics, ML and storytelling with data.',['Python with NumPy and Pandas','Statistics and probability','Data visualisation','Machine learning basics','SQL for analysts','Capstone project']],
['UI/UX Design','Design','🎨','Research, wireframes, prototyping and usability.',['Design principles and typography','User research','Wireframing in Figma','Prototyping','Usability testing','Portfolio case studies']],
['Cybersecurity','Security','🔐','Networks, ethical hacking and defensive practice.',['Networking fundamentals','Linux and command line','Core security concepts','Ethical hacking tools','Practice labs and CTFs','Certifications (Security+, CEH)']],
['AI/ML','Data','🤖','Math basics, models, deep learning and projects.',['Linear algebra and calculus basics','Python for ML','Supervised and unsupervised learning','Deep learning frameworks','NLP and computer vision','Deploy an ML project']],
['Full Stack Developer','Development','💻','Frontend, backend, databases and deployment end to end.',['Master HTML, CSS and JavaScript','Learn React or Vue','Build APIs with Node.js and Express','Work with SQL and MongoDB','Authentication and security basics','Deploy a full-stack app']],
['Python Developer','Development','🐍','Python fundamentals, automation, APIs and web frameworks.',['Python syntax and data structures','Functions, modules and OOP','File handling and automation','Flask or Django basics','Build and consume REST APIs','Publish a project on GitHub']],
['Mobile App Development','Development','📱','Build Android and iOS apps with modern frameworks.',['Learn Dart or Kotlin basics','Understand app UI and navigation','State management','Connect to APIs and storage','Test on real devices','Publish to the Play Store']],
['Cloud and DevOps','Cloud','☁️','Cloud platforms, containers, CI/CD and infrastructure.',['Linux and networking basics','Learn AWS or Azure core services','Docker and containers','CI/CD with GitHub Actions','Kubernetes fundamentals','Infrastructure as code with Terraform']],
['Digital Marketing','Business','📣','SEO, social media, content and analytics for growth.',['Marketing fundamentals','SEO and keyword research','Content and social media strategy','Paid ads on Google and Meta','Email marketing automation','Analytics and reporting']],
['Product Management','Business','🧭','Discovery, roadmaps, metrics and working with engineering.',['Understand users and problems','Write PRDs and user stories','Prioritisation frameworks','Roadmapping and stakeholder work','Metrics and experimentation','Launch and iterate on a product']]];
const RES=[
['10 Resume Tips That Get Interviews','Resume Tips','Resume','Keep your resume to one page if you have under five years of experience.\nStart with a 2-line summary that states your goal and your strongest skill.\nBegin every bullet with an action verb such as built, led, improved or designed.\nAdd numbers wherever possible: users, percentages, time saved or revenue.\nCopy keywords from the job post so applicant tracking systems rank you higher.\nUse a clean font, consistent spacing and save the file as a PDF before sending.'],
['Quantify Your Achievements','Resume Tips','Resume','Recruiters scan quickly, and numbers make your impact easy to see.\nReplace duties with outcomes: "Cut page load time by 40%" beats "Worked on website speed".\nUse the formula: action verb + what you did + measurable result.\nIf you have no exact figures, estimate honestly: team size, users, hours saved or number of projects.\nFor students, quantify projects: features built, test users, GitHub stars or hackathon rank.\nRead each bullet and ask "so what?" until the result is clear.'],
['Fresher Resume Mistakes to Avoid','Resume Tips','Resume','Writing a long career objective instead of a short, focused summary.\nListing every school subject instead of highlighting relevant projects and skills.\nUsing an unprofessional email address or an outdated phone number.\nLeaving spelling and grammar mistakes that show a lack of attention to detail.\nAdding a photo, date of birth or personal details that are not required.\nSending the same resume to every company without tailoring it to the role.'],
['Skills Section That Works','Resume Tips','Resume','Group skills into clear categories: Languages, Frameworks, Databases and Tools.\nList only skills you can confidently discuss or demonstrate in an interview.\nPut the skills that match the job post first so they are seen immediately.\nAvoid vague items like "hard working" and show soft skills through project results.\nAdd a proficiency hint only if it is honest, such as Strong, Working or Basic.\nUpdate this section for every application and remove outdated technologies.'],
['Modern One-Page Template','Templates','Resume','NAME SURNAME\nCity | Email | Phone | LinkedIn | GitHub\n\nSUMMARY\nTwo lines about your goal, your strongest skills and what you want to build.\n\nSKILLS\nLanguages: ...\nFrameworks: ...\nTools: ...\n\nPROJECTS\nProject Name | Tech stack | Link\n- What you built and the problem it solves\n- Result with a number (users, speed, accuracy)\n\nEXPERIENCE / INTERNSHIPS\nRole, Company, Dates\n- Achievement with an action verb and a result\n\nEDUCATION\nDegree, College, Year, CGPA\n\nCERTIFICATIONS AND ACHIEVEMENTS\n- Course or award, issuer, year'],
['ATS-Friendly Template','Templates','Resume','Use a single-column layout with no tables, text boxes, icons or images.\nStick to standard headings: Summary, Skills, Experience, Projects, Education.\nChoose a simple font such as Arial, Calibri or Times New Roman at size 10 to 12.\nWrite dates in one format, for example Jan 2025 - Jun 2025, across the whole resume.\nInclude exact keywords from the job description in your skills and bullets.\nSave as PDF or DOCX as requested and name it Firstname_Lastname_Resume.'],
['Creative Designer Template','Templates','Resume','NAME SURNAME - UI/UX Designer\nPortfolio link | Email | Phone | Behance or Dribbble\n\nABOUT ME\nShort personal statement about your design style and goals.\n\nTOOLS\nFigma, Adobe XD, Photoshop, Illustrator, Notion\n\nSELECTED WORK\nProject Name - Your role - Year\n- Problem, process and final outcome in one line each\n\nEXPERIENCE\nRole, Company, Dates\n- Key design contribution and its impact\n\nEDUCATION AND AWARDS\nDegree, College, Year\nAwards, hackathons and exhibitions'],
['Technical Fresher Template','Templates','Resume','NAME SURNAME\nEmail | Phone | GitHub | LinkedIn | Portfolio\n\nTECHNICAL SKILLS\nLanguages | Frameworks | Databases | Tools | Cloud\n\nPROJECTS\n1. Project Title | Tech stack | Live link\n- What it does and who it is for\n- Your contribution and a measurable result\n2. Project Title | Tech stack | Live link\n- Key features and challenges solved\n\nINTERNSHIPS\nRole, Company, Dates\n- Task completed, tool used, outcome\n\nEDUCATION\nDegree, College, Year, CGPA and relevant coursework\n\nCERTIFICATIONS'],
['How ATS Screens Your Resume','Articles','Resume','An applicant tracking system stores resumes and ranks them against the job post.\nIt scans for exact keywords such as skills, tools, job titles and qualifications.\nComplex layouts, tables and images can confuse the parser and hide your content.\nMirror the wording of the job description, for example "Machine Learning" not just "ML".\nPlace important keywords in your summary, skills and experience bullets naturally.\nSubmit the file type requested and check how your text looks when you copy it.'],
['Cover Letter Tips','Articles','Resume','Address the hiring manager by name when you can find it on LinkedIn or the job post.\nOpen with one strong sentence about why this role and company excite you.\nShow two relevant achievements with numbers instead of repeating your resume.\nConnect your skills directly to the needs mentioned in the job description.\nClose confidently with a clear next step, such as asking for a short call.\nKeep it under 250 words and proofread it twice before sending.'],
['Writing a Strong LinkedIn Summary','Articles','Career','Start with who you are and what you do in a single clear sentence.\nMention the people or problems you help, such as users, teams or customers.\nAdd two or three achievements with numbers to build instant credibility.\nList the skills and tools you want to be found for, using natural keywords.\nShare what you are currently learning to show growth and curiosity.\nEnd with an invitation to connect and an easy way to contact you.'],
['Networking for Beginners','Articles','Career','Networking is about building real conversations, not collecting connections.\nStart with alumni, seniors and people working in roles you want.\nSend a short personal message with one specific question instead of asking for a job.\nThank people for their time and share what you did with their advice.\nCommit to small actions every week: two messages, one comment and one event.\nStay in touch by sharing useful articles and updates on your progress.'],
['Java Roadmap Guide','Guides','Roadmaps','Month 1: learn Java syntax, variables, loops, methods and object-oriented programming.\nMonth 2: practise collections, generics, exceptions, streams and file handling.\nMonth 3: learn SQL, JDBC and basic database design with a small project.\nMonth 4: build REST APIs with Spring Boot, including validation and security basics.\nMonth 5: learn Git, Maven, unit testing with JUnit and simple deployment.\nMonth 6: build and publish a full project, then prepare for interviews.'],
['Python Cheat Sheet','Guides','Skills','Data types: int, float, str, list, tuple, set and dict, with slicing and common methods.\nControl flow: if, elif, else, for and while loops, plus list comprehensions.\nFunctions: default arguments, return values, lambda and *args / **kwargs.\nFiles and errors: open(), with statements and try / except / finally blocks.\nProjects: create virtual environments, install packages with pip and organise modules.\nUseful libraries: requests, pandas, numpy, matplotlib and flask.'],
['Git and GitHub Guide','Guides','Skills','Start a repository with git init and track changes with git add and git commit.\nWrite clear commit messages that say what changed and why.\nUse branches for new features, then merge them back through pull requests.\nResolve merge conflicts calmly by reading both versions before choosing.\nPush projects to GitHub and add a README with screenshots and setup steps.\nKeep your profile active: pin your best projects and commit regularly.'],
['Aptitude Preparation Guide','Guides','Interview','Practise for 30 to 45 minutes every day instead of studying in long, rare sessions.\nRevise formulas for percentages, ratios, averages, time and work, and speed and distance.\nSolve logical reasoning sets such as series, coding-decoding and seating arrangements.\nLearn shortcuts, but first make sure you understand the basic method.\nTake one timed mock test every week and analyse every wrong answer.\nKeep a notebook of mistakes and revise it before the real test.'],
['Building a Standout Portfolio','Blogs','Career','Show three or four polished projects instead of many unfinished ones.\nFor each project, explain the problem, your solution, the tools used and the result.\nAdd live demo links, clean GitHub repositories and screenshots.\nWrite a short, friendly About section with your skills and career goal.\nMake the site fast, mobile friendly and easy to navigate.\nInclude contact details and update the portfolio after each new project.'],
['Switching Careers Into Tech','Blogs','Career','Choose one clear path, such as web development, data or design, and stay focused.\nUse free and paid courses, but spend most of your time building real projects.\nShow how your past experience helps, for example communication, domain knowledge or leadership.\nLearn in public by sharing progress on LinkedIn or a blog.\nTalk to people already in the role and ask what skills matter most.\nApply for internships, freelance work or junior roles to gain experience quickly.'],
['Lessons From My First Internship','Blogs','Career','Ask questions early, because getting stuck silently costs more time than asking.\nWrite down what you learn each day so you can explain it later.\nDeliver small tasks quickly and show progress instead of waiting for perfection.\nAsk your mentor for feedback every two weeks and act on it.\nLearn how the team works: tools, meetings, code reviews and documentation.\nKeep a record of your contributions to use in your resume and interviews.'],
['How I Cracked Campus Placements','Blogs','Career','I started aptitude practice six months before the placement season began.\nI built two strong projects and could explain every technical decision in them.\nI revised core subjects: data structures, DBMS, operating systems and OOP.\nI gave one mock interview every week and recorded myself to improve.\nI prepared stories using the STAR method for common HR questions.\nI stayed calm, researched each company and asked thoughtful questions at the end.']];
const IQ=[
['What motivates you?','HR Questions','Connect your motivation to the role: learning, solving problems and seeing your work help users. Give a short real example.'],
['Tell me about yourself.','HR Questions','Present, past, future in 60 seconds: current studies or role, key projects, and why this job is your next step.'],
['Why should we hire you?','HR Questions','Match 2 or 3 of your strongest skills to their needs and back each with a result.'],
['What are your strengths?','HR Questions','Choose strengths relevant to the job and give one example for each.'],
['What is your biggest weakness?','HR Questions','Pick a real but minor weakness, show what you are doing to improve it and the progress so far.'],
['Where do you see yourself in 5 years?','HR Questions','Show ambition aligned with the company: growing skills, taking more responsibility and contributing to larger projects.'],
['Why do you want to work here?','HR Questions','Mention specific products, values or projects you researched and connect them to your goals.'],
['How do you handle pressure or conflict?','HR Questions','Stay calm, prioritise, communicate early and focus on the problem. Share a short example with the result.'],
['Explain OOP concepts.','Technical','Encapsulation, inheritance, polymorphism and abstraction, each with a one-line real-world example.'],
['Difference between SQL and NoSQL?','Technical','SQL uses fixed schemas and joins; NoSQL stores flexible data (documents, key-value) and scales horizontally.'],
['What happens when you type a URL in a browser?','Technical','DNS lookup, TCP/TLS connection, HTTP request, server response, then the browser parses HTML and renders the page.'],
['What is REST and how does it work?','Technical','An architecture using HTTP methods (GET, POST, PUT, DELETE) on resource URLs, stateless requests and JSON responses.'],
['What is database normalisation?','Technical','Organising tables to reduce redundancy and keep data consistent, through normal forms such as 1NF, 2NF and 3NF.'],
['Stack vs queue?','Technical','A stack is last-in first-out (undo history); a queue is first-in first-out (print jobs).'],
['Explain the JavaScript event loop.','Technical','JavaScript runs one task at a time; async callbacks wait in queues and the event loop pushes them to the call stack when it is empty.'],
['Process vs thread?','Technical','A process has its own memory space; threads share the memory of their process and are lighter to create.'],
['Trains speed and distance problems','Aptitude','Use distance = speed x time. For relative speed add speeds in opposite directions, subtract in the same direction.'],
['Percentages and profit/loss','Aptitude','Profit% = (profit / cost price) x 100. Convert percentages to fractions to calculate faster.'],
['Number series patterns','Aptitude','Check differences, ratios, squares/cubes and alternating patterns before anything else.'],
['Time and work problems','Aptitude','Find each worker rate as 1/days, add rates when working together, then take the reciprocal for total days.'],
['Ratio and proportion','Aptitude','Express quantities as parts of a total, find the value of one part, then multiply.'],
['Simple vs compound interest','Aptitude','Simple: SI = PRT/100. Compound: A = P(1 + R/100)^T. Compound interest grows on interest earned.'],
['Probability basics','Aptitude','Probability = favourable outcomes / total outcomes. For independent events multiply, for either-or events add.'],
['Permutations and combinations','Aptitude','Use permutations when order matters (nPr) and combinations when it does not (nCr).'],
['Is social media good for society?','GD Topics','Open with a balanced stance, give points for both sides with examples, and conclude with a practical middle path.'],
['Work from home vs office','GD Topics','Compare productivity, collaboration and wellbeing; suggest a hybrid model as a conclusion.'],
['Impact of AI on jobs','GD Topics','Discuss tasks automated, new roles created and the need for reskilling.'],
['Online learning vs classroom learning','GD Topics','Compare flexibility, cost and engagement with discipline and practical exposure; blended learning works best.'],
['Startups vs MNCs','GD Topics','Weigh learning speed and ownership against stability, structure and benefits.'],
['Should cryptocurrency be regulated?','GD Topics','Discuss innovation and inclusion against fraud and volatility; propose balanced, clear regulation.'],
['Technology and climate change','GD Topics','Cover clean energy and smart systems versus e-waste and data centre energy use.'],
['Influencer culture: opportunity or risk?','GD Topics','Mention new careers and reach against pressure, misinformation and unrealistic standards.'],
['Dress and body language basics','Tips','Dress one level above the company norm, sit upright, make eye contact and smile naturally.'],
['Research the company','Tips','Read their product pages, recent news and values; prepare 2 questions to ask the interviewer.'],
['Use the STAR method','Tips','Situation, Task, Action, Result: a simple structure for behavioural answers.'],
['Send a follow-up email','Tips','Within 24 hours thank the interviewer, mention one discussion point and restate your interest in two lines.'],
['Negotiating salary','Tips','Research market ranges, state your expectation as a range, and highlight the value you bring before discussing numbers.'],
['Online interview setup','Tips','Test camera, mic and internet, use a quiet well-lit space with a plain background, and keep notes nearby.'],
['Handling nervousness','Tips','Prepare and rehearse aloud, breathe slowly, pause before answering and remember it is a conversation.'],
['Questions to ask the interviewer','Tips','Ask about team goals, day-to-day work, growth opportunities and how success is measured.']];
const ANN=[['New Career Roadmap Added','Check out our new Data Science roadmap.','20 May 2025'],['Interview Mock Session','Join our free mock interview sessions.','18 May 2025'],['Resume Templates Updated','New ATS friendly templates are available.','15 May 2025']];
const USERS=[
['Aarav Shah','aarav@mail.com','Downloaded Resource','2 mins ago','Rajkot','12 Jan 2026','Active','Web Development'],
['Diya Patel','diya@mail.com','Started Roadmap','10 mins ago','Ahmedabad','03 Feb 2026','Active','Data Science'],
['Kabir Mehta','kabir@mail.com','Completed Interview','30 mins ago','Surat','21 Feb 2026','Active','Java Developer'],
['Isha Rao','isha@mail.com','Downloaded Template','1 hour ago','Vadodara','05 Mar 2026','Active','UI/UX Design'],
['Rohan Joshi','rohan@mail.com','Started Mock Interview','3 hours ago','Rajkot','18 Mar 2026','Active','Cybersecurity'],
['Meera Desai','meera@mail.com','Saved Roadmap','5 hours ago','Gandhinagar','02 Apr 2026','Active','AI/ML'],
['Harsh Trivedi','harsh@mail.com','Read Article','Yesterday','Bhavnagar','14 Apr 2026','Inactive','Python Developer'],
['Nisha Kapoor','nisha@mail.com','Completed Roadmap Step','Yesterday','Jamnagar','27 Apr 2026','Active','Full Stack Developer'],
['Dev Parmar','dev@mail.com','Downloaded Template','2 days ago','Rajkot','09 May 2026','Active','Mobile App Development'],
['Anjali Verma','anjali@mail.com','Started Roadmap','2 days ago','Surat','20 May 2026','Active','Digital Marketing'],
['Yash Solanki','yash@mail.com','Viewed Resource','3 days ago','Anand','01 Jun 2026','Inactive','Cloud and DevOps'],
['Pooja Nair','pooja@mail.com','Completed Interview','3 days ago','Ahmedabad','15 Jun 2026','Active','Product Management'],
['Krish Bhatt','krish@mail.com','Saved Resource','4 days ago','Rajkot','28 Jun 2026','Active','Web Development'],
['Sanya Gupta','sanya@mail.com','Started Mock Interview','5 days ago','Vadodara','10 Jul 2026','Active','Data Science'],
['Tanmay Modi','tanmay@mail.com','Read Article','6 days ago','Morbi','24 Jul 2026','Inactive','Java Developer'],
['Riya Chauhan','riya@mail.com','Downloaded Resource','1 week ago','Surat','05 Aug 2026','Active','UI/UX Design']];
const TH={
Blue:['#2563eb','#1d4ed8','#0a1f5c','#12308a','#eaf1ff','#f2f6fd'],
Indigo:['#4f46e5','#4338ca','#1e1b4b','#312e81','#eef2ff','#f3f4fe'],
Purple:['#9333ea','#7e22ce','#2e1065','#4c1d95','#f5eaff','#f8f3fe'],
Sky:['#0284c7','#0369a1','#082f49','#0c4a6e','#e6f5fd','#f0f8fd'],
Teal:['#0d9488','#0f766e','#083c3a','#0f5a55','#e6f7f5','#f0faf9'],
Emerald:['#16a34a','#15803d','#052e16','#14532d','#e8f8ee','#f0faf3'],
Orange:['#ea580c','#c2410c','#431407','#7c2d12','#fff1e6','#fff8f3'],
Rose:['#e11d48','#be123c','#4c0519','#881337','#ffe9ef','#fff5f7'],
Slate:['#475569','#334155','#0f172a','#1e293b','#eef1f5','#f4f6f9']};
const ld=(k,d)=>{try{return Object.assign(d,JSON.parse(localStorage.getItem(k))||{})}catch(e){return d}};
const CFG=ld('cl_cfg',{site:'CareerLaunch',theme:'Blue',bh:'Build Your Career, Shape Your Future',bp:'Roadmaps, resume help and interview prep in one place.',pw:{},em:{},nm:{}});
const UD=ld('cl_usr',{saved:['Web Development','Java Developer'],done:{},res:[],mocks:0,goals:[],streak:0,last:''});
{const td=new Date().toDateString();if(UD.last!=td){UD.streak=UD.last==new Date(Date.now()-864e5).toDateString()?(UD.streak||0)+1:1;UD.last=td}}
const STU=(()=>{try{const s=JSON.parse(localStorage.getItem('cl_students'));if(Array.isArray(s))return s}catch(e){}return[{name:'User',email:'user@example.com',pw:'user123',city:'',address:''}]})();
const saveStu=()=>{try{localStorage.setItem('cl_students',JSON.stringify(STU))}catch(e){}};
const D={rm:RM,res:RES,iq:IQ,an:ANN};
const sd=ld('cl_data4',{});if(sd.rm){RM.splice(0,RM.length,...sd.rm);RES.splice(0,RES.length,...sd.res);IQ.splice(0,IQ.length,...sd.iq);ANN.splice(0,ANN.length,...sd.an)}
const save=()=>{try{localStorage.setItem('cl_data4',JSON.stringify({rm:RM,res:RES,iq:IQ,an:ANN}));localStorage.setItem('cl_cfg',JSON.stringify(CFG));localStorage.setItem('cl_usr',JSON.stringify(UD))}catch(e){}};
const ST={q:new URLSearchParams(location.search).get('q')||'',cat:'All',tab:'Resume Tips',itab:'HR Questions',pg:1,open:null};
const PER=6;

// Helpers shared by all pages
const $=s=>document.querySelector(s);
const P={};
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const fn=(p,g)=>p=='u'?(g=='home'?'home.html':g+'.html'):'admin-'+g+'.html';
const GO=h=>{const m=h.match(/^#\/(\w)\/(\w+)$/);return m?fn(m[1],m[2]):h};
function applyTheme(n){const t=TH[n||CFG.theme]||TH.Blue,r=document.documentElement.style;['--ac','--ac2','--side','--side2','--soft','--bg'].forEach((v,i)=>r.setProperty(v,t[i]))}
applyTheme();
const ph=i=>`<div class="ic">${i}</div>`;
const ft=()=>`<footer><span>© 2025 ${esc(CFG.site)}</span><span>Privacy | Terms</span></footer>`;
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('s');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('s'),1800)};
function pg(l){const n=Math.max(1,Math.ceil(l.length/PER));ST.pg=Math.min(Math.max(1,ST.pg),n);return l.slice((ST.pg-1)*PER,ST.pg*PER)}
function pager(l){const n=Math.max(1,Math.ceil(l.length/PER));if(n<2)return'';let h=`<button data-pg="prev" ${ST.pg<=1?'disabled':''}>Previous</button>`;
for(let i=1;i<=n;i++)h+=`<button data-pg="${i}" class="${i==ST.pg?'on':''}">${i}</button>`;
return`<div class="pg">${h}<button data-pg="next" ${ST.pg>=n?'disabled':''}>Next</button></div>`}
const kp=(i,v,l,col,t)=>`<div class="card kp" style="--c:${col}"><div class="ki">${i}</div><div><b>${v}</b><span>${l}</span>${t?`<div class="up">${t}</div>`:''}</div></div>`;
const tabs=(list,key)=>`<div class="tabs">${list.map(t=>`<button class="${ST[key]==t?'on':''}" data-tab="${key}|${t}">${t}</button>`).join('')}</div>`;
const rmCard=r=>`<div class="card">${ph(r[2])}<b>${esc(r[0])}</b><p>${esc(r[3])}</p><button class="btn" data-view="${RM.indexOf(r)}">View Roadmap</button></div>`;
function modal(t,h){let m=$('#md');if(!m){m=document.createElement('div');m.id='md';document.body.append(m)}
m.innerHTML=`<div class="mb" role="dialog" aria-modal="true"><div class="mh"><h2>${t}</h2><button class="ib" data-close aria-label="Close">✕</button></div>${h}</div>`;m.style.display='block'}
const closeM=()=>{const m=$('#md');if(m)m.style.display='none';applyTheme()};

// Renders the current page and handles all clicks/inputs
function render(){
const panel=document.body.dataset.panel,page=document.body.dataset.page,nav=panel=='u'?UN:AN;
$('.logo').innerHTML=esc(CFG.site).replace(/^(Career)(.+)$/,'$1<b>$2</b>')+'<span id="adm">'+(panel=='a'?' Admin':'')+'</span>';
$('#side').innerHTML=nav.map(n=>`<a href="${fn(panel,n[0])}" class="${n[0]==page?'on':''}"><span>${n[1]}</span>${n[2]}</a>`).join('');
if(!$('#lo')){const l=document.createElement('a');l.id='lo';l.className='sw';l.textContent='Logout';l.href='#';$('#av').after(l)}
$('#av').textContent=cu&&cu.name?cu.name[0]:'U';$('#av').style.cursor='pointer';$('#av').title='My profile';$('#av').onclick=()=>location.href=fn(panel,panel=='a'?'profile':'editprofile');
const s=$('#swt');s.style.display=(panel=='u'&&cu&&cu.role!='admin')?'none':'';s.textContent=panel=='u'?'Admin Panel':'User Panel';s.href=panel=='u'?'admin-dashboard.html':'home.html';
$('#m').innerHTML=P[panel][page]();$('#side').classList.remove('o');document.title=CFG.site+' – '+nav.find(n=>n[0]==page)[2];
save();
}
const tgl=(a,v)=>{const i=a.indexOf(v);i<0?a.push(v):a.splice(i,1)};
if($('#bg'))$('#bg').onclick=()=>$('#side').classList.toggle('o');
document.addEventListener('click',e=>{
if(e.target.id=='md'){closeM();return}
const t=e.target.closest('[data-go],[data-tab],[data-pg],[data-add],[data-del],[data-ed],[data-view],[data-vres],[data-save],[data-sres],[data-dl],[data-xp],[data-mock],[data-set],[data-close],[data-search],[data-goal]');if(!t)return;const d=t.dataset;
if(d.go)location.href=GO(d.go);
else if(d.close!==undefined)closeM();
else if(d.search!==undefined)location.href='roadmaps.html?q='+encodeURIComponent($('#hs').value);
else if(d.tab){const[k,v]=d.tab.split('|');ST[k]=v;ST.pg=1;ST.open=null;render()}
else if(d.pg){ST.pg=d.pg=='prev'?ST.pg-1:d.pg=='next'?ST.pg+1:+d.pg;render();scrollTo(0,0)}
else if(d.add)form(d.add);
else if(d.ed){const[k,i]=d.ed.split('|');form(k,+i)}
else if(d.del){const[k,i]=d.del.split('|');if(confirm('Delete this item?')){D[k].splice(+i,1);render();toast('Deleted')}}
else if(d.view!==undefined)rmModal(+d.view);
else if(d.vres!==undefined)resModal(+d.vres);
else if(d.save!==undefined){tgl(UD.saved,RM[+d.save][0]);save();render();rmModal(+d.save);toast('Updated saved roadmaps')}
else if(d.sres!==undefined){tgl(UD.res,RES[+d.sres][0]);save();render();resModal(+d.sres);toast('Updated saved resources')}
else if(d.dl!==undefined){const r=RES[+d.dl],a=document.createElement('a');a.href=URL.createObjectURL(new Blob([r[3]],{type:'text/plain'}));a.download=r[0].replace(/\W+/g,'_')+'.txt';a.click()}
else if(d.xp!==undefined){ST.open=ST.open===+d.xp?null:+d.xp;render()}
else if(d.mock!==undefined){if(d.mock=='start')mock();else{MK.i++;mock(1)}}
else if(d.set)setf(d.set);
else if(d.goal!==undefined){tgl(UD.goals,+d.goal);save();render()}
});
document.addEventListener('input',e=>{if(e.target.id=='rq'){ST.q=e.target.value;ST.pg=1;const p=e.target.selectionStart;render();const i=$('#rq');i.focus();i.setSelectionRange(p,p)}});
document.addEventListener('change',e=>{const t=e.target;
if(t.name=='theme')applyTheme(t.value);
if(t.id=='rc'){ST.cat=t.value;ST.pg=1;render()}
if(t.dataset.step){const[i,k]=t.dataset.step.split('|'),n=RM[+i][0];UD.done[n]=UD.done[n]||[];tgl(UD.done[n],+k);save();render();rmModal(+i)}});
document.addEventListener('keydown',e=>{
if(e.key=='Escape')closeM();
if(e.key=='Enter'&&e.target.id=='hs')location.href='roadmaps.html?q='+encodeURIComponent(e.target.value);
if((e.key=='Enter'||e.key==' ')&&e.target.matches('[data-set],[data-lo]')){e.preventDefault();e.target.click()}});
document.addEventListener('submit',e=>{e.preventDefault();const f=e.target,fd=new FormData(f),k=f.dataset.k;
if(f.id=='fm'){const m=FM[k],i=f.dataset.i,v=(fd.get('0')||'').trim();if(!v)return;
const it=i===''?m.def.slice():m.a[+i];m.f.forEach(([l,x])=>it[x]=(fd.get(String(x))||'').trim());
if(i==='')m.a.push(it);
closeM();render();toast(i===''?'Added':'Saved');return}
if(f.id=='sf'){const er=m=>{$('#se').textContent=m};
if(k=='theme'){CFG.theme=fd.get('theme');applyTheme()}
if(k=='profile'){const ph=(fd.get('phone')||'').trim();const pe=checkPhone(ph);if(pe)return er(pe);CFG.ph=CFG.ph||{};CFG.ph[cu.role]=ph;cu.name=fd.get('name').trim();cu.email=fd.get('email').trim().toLowerCase();CFG.em[cu.role]=cu.email;CFG.nm=CFG.nm||{};CFG.nm[cu.role]=cu.name;try{sessionStorage.setItem('cl_user',JSON.stringify(cu))}catch(x){}}
if(k=='pw'){const cur=CFG.pw[cu.role]||CRED[cu.role][1],n1=fd.get('n1');
if(fd.get('cur')!=cur)return er('Current password is incorrect.');const pw2=checkPasswordLength(n1)||checkPasswordPattern(n1);if(pw2)return er(pw2);if(n1!=fd.get('n2'))return er('New passwords do not match.');CFG.pw[cu.role]=n1}
closeM();render();toast('Saved')}});
document.addEventListener('keyup',()=>{});
document.addEventListener('DOMContentLoaded',()=>{if(!LOGIN)render()});
// ----- login page -----
if(LOGIN){let role='user';
$('#rt').onclick=e=>{const b=e.target.closest('button');if(!b)return;role=b.dataset.r;document.querySelectorAll('#rt button').forEach(x=>x.classList.toggle('on',x==b));$('#er').textContent=''};
$('#f').onsubmit=e=>{e.preventDefault();const c=CRED[role],inE=$('#em').value.trim().toLowerCase(),inP=$('#pw').value;
const ve=validateLogin($('#em').value.trim(),inP);if(ve){$('#er').textContent=ve;return}
let nm,em;
if(role=='user'){const s=STU.find(x=>x.email.toLowerCase()==inE&&x.pw==inP);if(!s){$('#er').textContent='Email or password is incorrect. Try again.';return}nm=s.name;em=s.email}
else{em=(CFG.em[role]||c[0]).toLowerCase();const pw=CFG.pw[role]||c[1];if(inE!=em||inP!=pw){$('#er').textContent='Email or password is incorrect. Try again.';return}nm=(CFG.nm&&CFG.nm.admin)||c[2]}
try{sessionStorage.setItem('cl_user',JSON.stringify({role,name:nm,email:em}))}catch(x){}
location.href=c[3]}}
