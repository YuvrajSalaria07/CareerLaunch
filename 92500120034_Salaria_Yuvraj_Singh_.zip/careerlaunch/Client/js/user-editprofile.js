// ===== User: Edit Profile page =====
P.u = P.u || {};

P.u.editprofile = () => {
  const s = STU.find(x => x.email.toLowerCase() == cu.email.toLowerCase()) || { name: cu.name, email: cu.email, city: '', address: '' };
  return `
<div class="pt"><h1>Edit Profile</h1></div>
<div class="card fc">
  <form id="ep" novalidate>
    <label>Name</label><input name="name" value="${esc(s.name)}">
    <label>Email</label><input name="email" type="email" value="${esc(s.email)}">
    <label>City</label><input name="city" value="${esc(s.city)}">
    <label>Address</label><input name="address" value="${esc(s.address)}">
    <h2>Change Password <small class="mu">(leave blank to keep current)</small></h2>
    <label>Current password</label><input name="cur" type="password" autocomplete="current-password">
    <label>New password</label><input name="n1" type="password" autocomplete="new-password">
    <label>Confirm new password</label><input name="n2" type="password" autocomplete="new-password">
    <div class="lg-e" id="pe" role="alert"></div>
    <button class="btn" type="submit">Save Changes</button>
  </form>
</div>${ft()}`;
};

document.addEventListener('submit', e => {
  if (e.target.id != 'ep') return;
  const fd = new FormData(e.target);
  const err = m => { $('#pe').textContent = m; };
  const name = fd.get('name').trim(), email = fd.get('email').trim().toLowerCase();
  const cur = fd.get('cur'), n1 = fd.get('n1'), n2 = fd.get('n2');

  const s = STU.find(x => x.email.toLowerCase() == cu.email.toLowerCase());
  if (!s) return err('Student record not found. Please log in again.');

  if (!name) return err('Enter your name.');
  const bad = checkEmail(email);
  if (bad) return err(bad);
  if (STU.some(x => x !== s && x.email.toLowerCase() == email)) return err('This email is already used by another student.');

  // password is changed only when something is typed in the password boxes
  if (cur || n1 || n2) {
    if (cur != s.pw) return err('Current password is incorrect.');
    const pe = checkPasswordLength(n1) || checkPasswordPattern(n1);
    if (pe) return err(pe);
    if (n1 != n2) return err('New passwords do not match.');
    s.pw = n1;
  }

  s.name = name; s.email = email;
  s.city = fd.get('city').trim(); s.address = fd.get('address').trim();
  saveStu();

  cu.name = name; cu.email = email;
  try { sessionStorage.setItem('cl_user', JSON.stringify(cu)); } catch (x) {}
  render();
  toast('Profile updated');
});
