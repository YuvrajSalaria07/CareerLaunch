// ===== Admin: Add Student page =====
P.a = P.a || {};

P.a.addstudent = () => `
<div class="pt"><h1>Add Student</h1></div>
<div class="card fc">
  <form id="as" novalidate>
    <label>Full name</label><input name="name" placeholder="Student name">
    <label>Email</label><input name="email" type="email" placeholder="student@example.com">
    <label>Password (min 6 characters, letter + number)</label><input name="pw" type="password">
    <label>City</label><input name="city">
    <label>Address</label><input name="address">
    <div class="lg-e" id="ae" role="alert"></div>
    <button class="btn" type="submit">Add Student</button>
  </form>
</div>
<h2>All Students (${STU.length})</h2>
<div class="tw"><table><tr><th>Name</th><th>Email</th><th>City</th><th>Address</th><th>Action</th></tr>
${STU.map((s, i) => `<tr><td>${esc(s.name)}</td><td>${esc(s.email)}</td><td>${esc(s.city)}</td><td>${esc(s.address)}</td>
<td><button class="ib" data-dstu="${i}" title="Delete" aria-label="Delete">🗑</button></td></tr>`).join('') || '<tr><td colspan="5">No students yet.</td></tr>'}
</table></div>`;

// Add student
document.addEventListener('submit', e => {
  if (e.target.id != 'as') return;
  const fd = new FormData(e.target);
  const name = fd.get('name').trim(), email = fd.get('email').trim().toLowerCase(), pw = fd.get('pw');
  const err = m => { $('#ae').textContent = m; };

  if (!name || !email || !pw) return err('Name, email and password are required.');
  const bad = checkEmail(email) || checkPasswordLength(pw) || checkPasswordPattern(pw);
  if (bad) return err(bad);
  if (STU.some(s => s.email.toLowerCase() == email)) return err('A student with this email already exists.');

  STU.push({ name, email, pw, city: fd.get('city').trim(), address: fd.get('address').trim() });
  saveStu();
  render();
  toast('Student added');
});

// Delete student
document.addEventListener('click', e => {
  const b = e.target.closest('[data-dstu]');
  if (!b || !confirm('Delete this student?')) return;
  STU.splice(+b.dataset.dstu, 1);
  saveStu();
  render();
  toast('Student deleted');
});
