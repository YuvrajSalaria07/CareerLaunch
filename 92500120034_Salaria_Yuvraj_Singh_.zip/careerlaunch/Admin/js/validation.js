// ===== validation.js : all JavaScript form validations =====
// Every function returns an error message, or "" when the value is valid.

// 1. All fields are required
function checkRequired(email, password) {
  if (email === "" || password === "") {
    return "Enter your email and password.";
  }
  return "";
}

// 2. Email pattern (name@domain.com)
function checkEmail(email) {
  var pattern = /^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$/;
  if (!pattern.test(email)) {
    return "Enter a valid email address, e.g. you@example.com.";
  }
  return "";
}

// 3. Password length (minimum 6 characters)
function checkPasswordLength(password) {
  if (password.length < 6) {
    return "Password must be at least 6 characters long.";
  }
  return "";
}

// 4. Password pattern (at least one letter and one number)
function checkPasswordPattern(password) {
  var pattern = /^(?=.*[A-Za-z])(?=.*\d).+$/;
  if (!pattern.test(password)) {
    return "Password must contain at least one letter and one number.";
  }
  return "";
}

// 5. Phone number pattern (10 digits, starting with 6, 7, 8 or 9)
function checkPhone(phone) {
  if (phone === "") {
    return ""; // phone is optional
  }
  var pattern = /^[6-9]\d{9}$/;
  if (!pattern.test(phone)) {
    return "Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.";
  }
  return "";
}

// Login form: runs the checks one by one and returns the first error found
function validateLogin(email, password) {
  return checkRequired(email, password) ||
         checkEmail(email) ||
         checkPasswordLength(password) ||
         checkPasswordPattern(password);
}
